package com.timeshot

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var preview: ImageView
    private val ui = Handler(Looper.getMainLooper())
    private var shownVer = -1

    private val refresh = object : Runnable {
        override fun run() {
            status.text = Shared.statusText()
            if (Shared.previewVer != shownVer) redrawPreview()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(32, 48, 32, 48)
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        status = TextView(this)
        status.textSize = 16f
        root.addView(status)

        root.addView(btn("Запустить захват экрана") { askCapture() })
        root.addView(btn("Остановить") { stopService(Intent(this, CaptureService::class.java)) })

        root.addView(title("1. Зона всплывашки"))
        root.addView(note("Нажми кнопку, переключись в игру, вызови /time. Через несколько секунд телефон завибрирует — снимок для настройки готов, вернись сюда."))
        root.addView(seek("Задержка снимка", "learn", 5, 30, 12, " с") { })
        root.addView(btn("Снимок для настройки зоны") { learn("preview") })

        preview = ImageView(this)
        preview.adjustViewBounds = true
        preview.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        root.addView(preview)

        root.addView(seek("Зона: слева", "zl", 0, 95, 62, "%") { redrawPreview() })
        root.addView(seek("Зона: сверху", "zt", 0, 95, 55, "%") { redrawPreview() })
        root.addView(seek("Зона: справа", "zr", 5, 100, 100, "%") { redrawPreview() })
        root.addView(seek("Зона: снизу", "zb", 5, 100, 95, "%") { redrawPreview() })

        root.addView(title("2. Запомнить вид"))
        root.addView(note("Рамка должна охватывать всплывашку целиком. После смены зоны шаблоны нужно запомнить заново."))
        root.addView(btn("Запомнить /time (через N с)") { learn("time") })
        root.addView(btn("Запомнить PayDay — необязательно") { learn("pay") })

        root.addView(title("3. Настройки"))
        root.addView(seek("Порог совпадения", "thr", 40, 99, 80, "%") { })
        root.addView(seek("Пауза после скрина", "cd", 3, 60, 10, " с") { })
        root.addView(seek("Задержка перед скрином", "dl", 0, 2000, 400, " мс") { })
        root.addView(note("Скрины сохраняются в Галерею, папка Pictures/ArizonaTime."))
    }

    private fun btn(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setOnClickListener { onClick() }
        return b
    }

    private fun title(s: String): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = 18f
        t.setPadding(0, 40, 0, 8)
        return t
    }

    private fun note(s: String): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = 13f
        return t
    }

    private fun seek(label: String, key: String, min: Int, max: Int, def: Int, unit: String, onChange: () -> Unit): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val tv = TextView(this)
        val sb = SeekBar(this)
        val cur = prefs.getInt(key, def).coerceIn(min, max)
        sb.max = max - min
        sb.progress = cur - min
        tv.text = label + ": " + cur + unit
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                tv.text = label + ": " + v + unit
                prefs.edit().putInt(key, v).apply()
                onChange()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
        return box
    }

    private fun askCapture() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
            i.action = CaptureService.ACTION_START
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            startForegroundService(i)
        }
    }

    private fun learn(kind: String) {
        if (!Shared.running) {
            Toast.makeText(this, "Сначала запусти захват экрана", Toast.LENGTH_SHORT).show()
            return
        }
        val d = prefs.getInt("learn", 12)
        val i = Intent(this, CaptureService::class.java)
        i.action = CaptureService.ACTION_LEARN
        i.putExtra("kind", kind)
        i.putExtra("delay", d)
        startService(i)
        Toast.makeText(this, "Переключись в игру. Снимок через $d с, будет вибрация", Toast.LENGTH_LONG).show()
    }

    private fun redrawPreview() {
        val b = Shared.preview ?: return
        val c = b.copy(Bitmap.Config.ARGB_8888, true)
        val cv = Canvas(c)
        val paint = Paint()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.color = Color.RED
        val w = c.width.toFloat()
        val h = c.height.toFloat()
        cv.drawRect(
            prefs.getInt("zl", 62) / 100f * w, prefs.getInt("zt", 55) / 100f * h,
            prefs.getInt("zr", 100) / 100f * w, prefs.getInt("zb", 95) / 100f * h, paint
        )
        preview.setImageBitmap(c)
        shownVer = Shared.previewVer
    }

    override fun onResume() {
        super.onResume()
        ui.post(refresh)
    }

    override fun onPause() {
        ui.removeCallbacks(refresh)
        super.onPause()
    }
}
