package com.timeshot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val GW = 64
const val GH = 24

/** Общее состояние между сервисом и экраном приложения. */
object Shared {
    @Volatile var running = false
    @Volatile var msg = "остановлено"
    @Volatile var lastTime = 0f
    @Volatile var lastPay = -1f
    @Volatile var best = 0f
    @Volatile var shots = 0
    @Volatile var preview: Bitmap? = null
    @Volatile var previewVer = 0

    fun statusText(): String {
        val head = if (running) "● Работает" else "○ Остановлено"
        return head +
            "\nСовпадение с /time: " + "%.2f".format(lastTime) + " (лучшее " + "%.2f".format(best) + ")" +
            "\nСовпадение с PayDay: " + (if (lastPay < -0.5f) "—" else "%.2f".format(lastPay)) +
            "\nСкринов сохранено: " + shots +
            "\n" + msg
    }
}

/** Серая «подпись» зоны экрана: сетка GW x GH точек. */
fun signature(buf: ByteBuffer, rowStride: Int, pixelStride: Int, w: Int, h: Int, z: FloatArray): FloatArray {
    val x0 = (z[0] * w).toInt().coerceIn(0, w - 1)
    val y0 = (z[1] * h).toInt().coerceIn(0, h - 1)
    val x1 = (z[2] * w).toInt().coerceIn(x0 + 1, w - 1)
    val y1 = (z[3] * h).toInt().coerceIn(y0 + 1, h - 1)
    val zw = x1 - x0
    val zh = y1 - y0
    val out = FloatArray(GW * GH)
    for (j in 0 until GH) {
        val y = y0 + (j * zh) / GH
        for (i in 0 until GW) {
            val x = x0 + (i * zw) / GW
            val p = y * rowStride + x * pixelStride
            val r = buf.get(p).toInt() and 0xFF
            val g = buf.get(p + 1).toInt() and 0xFF
            val b = buf.get(p + 2).toInt() and 0xFF
            out[j * GW + i] = 0.299f * r + 0.587f * g + 0.114f * b
        }
    }
    return out
}

/** Нормированная корреляция двух подписей: 1.0 = одинаково, около 0 = ничего общего. */
fun ncc(a: FloatArray, b: FloatArray): Float {
    var ma = 0f
    var mb = 0f
    for (i in a.indices) { ma += a[i]; mb += b[i] }
    ma /= a.size
    mb /= b.size
    var num = 0f
    var da = 0f
    var db = 0f
    for (i in a.indices) {
        val x = a[i] - ma
        val y = b[i] - mb
        num += x * y
        da += x * x
        db += y * y
    }
    val d = Math.sqrt((da * db).toDouble()).toFloat()
    return if (d < 1e-3f) 0f else num / d
}

class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.timeshot.START"
        const val ACTION_LEARN = "com.timeshot.LEARN"
    }

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    private val main = Handler(Looper.getMainLooper())

    private var sw = 0
    private var sh = 0
    private var lastCheck = 0L
    private var hits = 0
    private var shotAt = 0L
    private var cooldownUntil = 0L
    private var learnAt = 0L
    private var learnKind = ""

    private var tplTime: FloatArray? = null
    private var tplPay: FloatArray? = null
    private var tzTime = ""
    private var tzPay = ""

    private val tick = object : Runnable {
        override fun run() {
            setupDisplay()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        thread = HandlerThread("timeshot")
        thread.start()
        handler = Handler(thread.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY
        when (intent.action) {
            ACTION_START -> startCapture(intent)
            ACTION_LEARN -> {
                if (!Shared.running) {
                    stopSelf()
                } else {
                    learnKind = intent.getStringExtra("kind") ?: ""
                    learnAt = SystemClock.elapsedRealtime() + intent.getIntExtra("delay", 12) * 1000L
                    Shared.msg = "снимок через " + intent.getIntExtra("delay", 12) + " с — переключись в игру"
                }
            }
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra<Intent>("data")

    private fun startCapture(intent: Intent) {
        if (projection != null) return

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("ts", "TimeShot", NotificationManager.IMPORTANCE_LOW))

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notif = Notification.Builder(this, "ts")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("TimeShot работает")
            .setContentText("Ждём всплывашку /time")
            .setContentIntent(open)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notif)
        }

        val code = intent.getIntExtra("code", 0)
        val data = readData(intent)
        if (data == null) { stopSelf(); return }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, main)
        projection = proj

        Shared.running = true
        Shared.best = 0f
        Shared.msg = "запущено"
        loadTemplates()
        handler.post(tick)
    }

    private fun setupDisplay() {
        try {
            val dm = DisplayMetrics()
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            if (dm.widthPixels == sw && dm.heightPixels == sh && vd != null) return
            sw = dm.widthPixels
            sh = dm.heightPixels

            val old = reader
            val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
            r.setOnImageAvailableListener(ImageReader.OnImageAvailableListener { onFrame(it) }, handler)
            reader = r

            val v = vd
            if (v == null) {
                vd = projection?.createVirtualDisplay(
                    "timeshot", sw, sh, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    r.surface, null, handler
                )
            } else {
                v.resize(sw, sh, dm.densityDpi)
                v.surface = r.surface
            }
            old?.close()
        } catch (e: Exception) {
            Shared.msg = "ошибка захвата: " + e.message
        }
    }

    private fun onFrame(rd: ImageReader) {
        val img: Image? = try { rd.acquireLatestImage() } catch (e: Exception) { null }
        if (img == null) return
        try {
            process(img)
        } catch (e: Exception) {
            Shared.msg = "ошибка: " + e.message
        } finally {
            img.close()
        }
    }

    private fun pi(key: String, def: Int): Int =
        getSharedPreferences("cfg", MODE_PRIVATE).getInt(key, def)

    private fun zoneKey(): String =
        pi("zl", 62).toString() + "_" + pi("zt", 55) + "_" + pi("zr", 100) + "_" + pi("zb", 95)

    private fun zone(): FloatArray =
        floatArrayOf(pi("zl", 62) / 100f, pi("zt", 55) / 100f, pi("zr", 100) / 100f, pi("zb", 95) / 100f)

    private fun parse(s: String?): FloatArray? {
        if (s.isNullOrEmpty()) return null
        val parts = s.split(",")
        if (parts.size != GW * GH) return null
        return FloatArray(parts.size) { parts[it].toFloat() }
    }

    private fun loadTemplates() {
        val sp = getSharedPreferences("cfg", MODE_PRIVATE)
        tplTime = parse(sp.getString("tpl_time", null))
        tzTime = sp.getString("tz_time", "") ?: ""
        tplPay = parse(sp.getString("tpl_pay", null))
        tzPay = sp.getString("tz_pay", "") ?: ""
    }

    private fun process(img: Image) {
        val now = SystemClock.elapsedRealtime()
        val p = img.planes[0]
        val buf = p.buffer
        val rs = p.rowStride
        val ps = p.pixelStride
        val w = img.width
        val h = img.height

        // Пора делать скриншот
        if (shotAt != 0L && now >= shotAt) {
            shotAt = 0L
            cooldownUntil = now + pi("cd", 10) * 1000L
            saveShot(img)
            return
        }

        if (now - lastCheck < 200) return
        lastCheck = now

        // Режим «запомнить»
        if (learnAt != 0L && now >= learnAt) {
            val kind = learnKind
            learnKind = ""
            learnAt = 0L
            buzz()
            if (kind == "preview") {
                val bmp = toBitmap(img)
                Shared.preview = Bitmap.createScaledBitmap(bmp, bmp.width / 4, bmp.height / 4, true)
                Shared.previewVer++
                Shared.msg = "снимок для настройки зоны готов"
            } else {
                val sig = signature(buf, rs, ps, w, h, zone())
                getSharedPreferences("cfg", MODE_PRIVATE).edit()
                    .putString("tpl_$kind", sig.joinToString(","))
                    .putString("tz_$kind", zoneKey())
                    .apply()
                loadTemplates()
                Shared.msg = "шаблон '$kind' сохранён"
            }
            return
        }

        if (now < cooldownUntil || shotAt != 0L) return

        val tt = tplTime
        if (tt == null) { Shared.msg = "нет шаблона /time — запомни его"; return }
        val zk = zoneKey()
        if (zk != tzTime) { Shared.msg = "зона изменилась — запомни /time заново"; return }

        val sig = signature(buf, rs, ps, w, h, zone())
        val sT = ncc(sig, tt)
        var sP = -1f
        val tp = tplPay
        if (tp != null && zk == tzPay) sP = ncc(sig, tp)

        Shared.lastTime = sT
        Shared.lastPay = sP
        if (sT > Shared.best) Shared.best = sT

        val thr = pi("thr", 80) / 100f
        if (sT >= thr && sT > sP + 0.03f) {
            hits++
            if (hits >= 2) {
                hits = 0
                shotAt = now + pi("dl", 400)
                Shared.msg = "поймал /time — снимаю"
            }
        } else {
            hits = 0
            Shared.msg = "ждём всплывашку"
        }
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val bw = p.rowStride / p.pixelStride
        val bmp = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
        p.buffer.rewind()
        bmp.copyPixelsFromBuffer(p.buffer)
        return if (bw != img.width) Bitmap.createBitmap(bmp, 0, 0, img.width, img.height) else bmp
    }

    private fun saveShot(img: Image) {
        val bmp = toBitmap(img)
        val name = "time_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".png"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ArizonaTime")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Shared.shots++
            Shared.msg = "сохранено: $name"
            buzz()
        } else {
            Shared.msg = "не удалось сохранить скриншот"
        }
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        v.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    override fun onDestroy() {
        Shared.running = false
        Shared.msg = "остановлено"
        handler.removeCallbacksAndMessages(null)
        try { vd?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        projection = null
        vd = null
        reader = null
        thread.quitSafely()
        super.onDestroy()
    }
}
